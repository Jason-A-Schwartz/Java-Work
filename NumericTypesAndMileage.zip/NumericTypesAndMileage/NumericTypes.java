// Jason Schwartz
// Lab Two Numeric Types

// TASK #2 Add an import statement for the Scanner class
import java.util.Scanner;
/**
   This program demonstrates how numeric types and
   operators behave in Java.
*/

public class NumericTypes
{
   public static void main (String [] args)
   {
      // TASK #2 Create a Scanner object here
      Scanner keyboard = new Scanner(System.in);
      // (not used for alternate)

      // Identifier declarations
      final double NUMBER = 2 ;        // Number of scores
      final double SCORE1 = 100;       // First test score
      final int SCORE2 = 95;        // Second test score
      final int BOILING_IN_F = 212; // Boiling temperature
      int fToC;                     // Temperature Celsius
      double average;               // Arithmetic average
      String output;                // Line of output

      // TASK #2 declare variables used here
      String firstName;
      String lastName;
      String fullName;

      // TASK #3 declare variables used here
      char firstInitial;
      int nameLength;
      // TASK #4 declare variables used here
      double Diameter;
      double Radius;
      double Volume;

      // Find an arithmetic average.
      average = (SCORE1 + SCORE2) / NUMBER;
      output = SCORE1 + " and " + SCORE2 +
               " have an average of " + average;
      System.out.println(output);

      // Convert Fahrenheit temperature to Celsius.
      fToC = (BOILING_IN_F - 32) * 5/9;
      output = BOILING_IN_F + " in Fahrenheit is " +
               fToC + " in Celsius.";
      System.out.println(output);
      System.out.println();      // To leave a blank line

      // ADD LINES FOR TASK #2 HERE
      // Prompt the user for first name
      System.out.print("Enter You'r First Name: ");
      // Read the user's first name
      firstName = keyboard.next();
      // Prompt the user for last name
      System.out.print("Enter You'r Last Name: ");
      // Read the user's last name
      lastName = keyboard.next();
      fullName = (firstName + " " + lastName);
      // Concatenate the user's first and last names
      System.out.print(fullName);

      // Print out the user's full name

      System.out.println();      // To leave a blank line

      // ADD LINES FOR TASK #3 HERE
      // Get the first character from the user's first name
      firstInitial = firstName.charAt(0);
      // Print out the user's first initial
      System.out.println(firstInitial);
      // Convert the user's full name to uppercase
      fullName = fullName.toUpperCase();
      // Print out the user's full name in uppercase
      System.out.println(fullName);
      // Find length of name
      nameLength = fullName.length();
      // Print name length
      System.out.println(nameLength);

      System.out.println();      // To leave a blank line

      // ADD LINES FOR TASK #4 HERE
      // Prompt the user for a diameter of a sphere
      System.out.println("Input Diameter Of The Sphere: ");
      // Read the diameter
      Diameter = keyboard.nextDouble();
      // Calculate the radius
      Radius = (Diameter / 2);
      // Calculate the volume
      Volume = ((4.0/3.0) * Math.PI * Math.pow(Radius, 3));
      // Print out the volume
      System.out.println("Volume Of The Spehere: " + Volume);

      keyboard.close();
   }
}