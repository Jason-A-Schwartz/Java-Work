// Jason Schwartz
// Lab Two Alternate Numeric Types

// TASK #2(Alternate)

import javax.swing.JOptionPane;

public class AlternateNumericTypes
{
   public static void main (String [] args)
   {

      // TASK #2 declare variables used here
      String firstName;
      String lastName;
      String fullName;

      // ADD LINES FOR TASK #2 alternate HERE
      // Prompt the user for first name
      firstName = JOptionPane.showInputDialog("Enter You'r First Name: ");
      // Prompt the user for last name
      lastName = JOptionPane.showInputDialog("Enter You'r Last Name: ");
      // Concatenate the user's first and last names
      fullName = (firstName + " " + lastName);
      // Print out the user's full name
      JOptionPane.showMessageDialog(null, fullName);
   }
}