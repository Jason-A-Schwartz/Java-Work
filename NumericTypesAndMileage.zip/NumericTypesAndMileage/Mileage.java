// Jason Schwartz
// This program determines mileage

// Import Scanner Class
import java.util.Scanner;

public class Mileage
{
   public static void main(String[] args) {

    // Declare Scanner Object
    Scanner keyboard = new Scanner(System.in);

    // Declare Variables For Miles Driven, Gallons Consumed And MPG Calculation
    double milesDriven;
    double gallonsConsumed;
    double MPG;

    // State What The Program Does
    System.out.println("This Program Will Calculate Mileage");

    // Prompt User To Input Of Miles Driven
    System.out.println("Enter Miles Driven");

    // Store User Input As Miles Driven
    milesDriven = keyboard.nextDouble();

    // Prompt User To Input Gallons Consumed
    System.out.println("Enter Gallons Consumed");

    // Store User Input As Gallons Cosumed
    gallonsConsumed = keyboard.nextDouble();

    // Calculate MPG By Dividing Miles Driven By Gallons Consumed
    MPG = (milesDriven/gallonsConsumed);
    // The Purpose Of The Above Calcualtion Is To Calcualte MPG

    // State The Calculated MPG 
    System.out.println("Miles Per Gallon Rate: " + MPG);

    //Prevent Resource Leak :)
    keyboard.close();
    }
}