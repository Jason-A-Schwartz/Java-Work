// Jason Schwartz
// Prints An Array 5 Times Statically

public class StaticArrays

{
    public static void main(String[] args)

   {
     
     //Array      
  
     System.out.println("---------------------");    

     System.out.println("Initial Array");

     MyArrayListStatic.print();
     
     System.out.println("---------------------");    

     System.out.println("Update Array: Change value in index 2 to 7");

     //Change value in index 2 changes from 5 to 7

     MyArrayListStatic.update(2,7); 

     MyArrayListStatic.print();
     
     System.out.println("---------------------");   

     System.out.println("Add value 3 to the end of the array");

     //Add value 3 to the end of the array

     MyArrayListStatic.add(3);

     MyArrayListStatic.print();
     
     System.out.println("---------------------");    

     System.out.println("Insert value 9 into index 3");

     //Insert value 9 into index 3 

     MyArrayListStatic.insert(3,9);

     MyArrayListStatic.print();
     
     System.out.println("---------------------");

     System.out.println("Delete the value in index 3");

     //Delete the value in index 3

     MyArrayListStatic.delete(3);

     MyArrayListStatic.print();
     
   }
}
   
 