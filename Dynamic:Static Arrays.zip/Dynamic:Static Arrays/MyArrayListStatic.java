// Jason Schwartz
// This is needed to run StaticArrays

public class MyArrayListStatic
    
    {

      // Initializes An Array

        public static int[] a = {2,8,5,4,6};

        // Method For HW4Static

        public static void update(int index, int value)

        {
     
           a[index] = value;
           
        }
     
        // Method For HW4Static
        
        public static void add(int value)
     
        {
     
           int[] temp = new int[a.length + 1];
     
           for (int i = 0 ; i < a.length; i++)
     
             temp[i] = a[i];
     
           temp[a.length] = value;

           a = temp;
        }
        
        // Method For HW4Static

        public static void insert(int index, int value)
     
        {
     
            int[] temp = new int[a.length + 1];
     
            for(int i=0 ; i < index ; i++)
     
              temp[i] = a[i];
     
            temp[index] = value;
     
            for(int i = index ; i < a.length; i++)
     
              temp[ i + 1] = a[i];

              a = temp;
     
        }

        // Method For HW4Static
        
        public static void delete(int index)
        
     
        {
     
            int[] temp = new int[a.length - 1];
     
            for(int i = 0; i < index; i++)
     
              temp[i] = a[i];
     
            for(int i = index + 1; i < a.length; i++)
     
              temp[ i - 1] = a[i];
     
            a = temp;
     
        }

        // Method For HW4Static
        
        public static void print()
     
        {
     
           for(int i = 0 ; i < a.length; i++)
     
             System.out.println("a[" + i + "]: " + a[i]); 
     
        }

    }