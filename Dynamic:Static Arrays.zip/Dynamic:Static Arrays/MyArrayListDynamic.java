// Jason Schwartz
// This is needed to run DynamicArrays

public class MyArrayListDynamic
    
    {
    
        // Created Constructor 

        public void Constructor() 

        {

            int[] a1 = {2,8,5,4,6};

            MyArrayListDynamic list1 = new MyArrayListDynamic (a1);

            list1.print();

        }

        // Initializes An Array

        public int[] a = {2,8,5,4,6};

        // Made Into Instance Method

        public void update(int index, int value)

        {
     
           a[index] = value;
           
        }

        // Made Into Instance Method
        
        public void add(int value)
     
        {
     
           int[] temp = new int[a.length + 1];
     
           for (int i = 0 ; i < a.length; i++)
     
             temp[i] = a[i];
     
           temp[a.length] = value;

           a = temp;
        }

        // Made Into Instance Method
        
        public void insert(int index, int value)
     
        {
     
            int[] temp = new int[a.length + 1];
     
            for(int i=0 ; i < index ; i++)
     
              temp[i] = a[i];
     
            temp[index] = value;
     
            for(int i = index ; i < a.length; i++)
     
              temp[ i + 1] = a[i];

              a = temp;
     
        }

        // Made Into Instance Method
        
        public void delete(int index)
     
        {
     
            int[] temp = new int[a.length - 1];
     
            for(int i = 0; i < index; i++)
     
              temp[i] = a[i];
     
            for(int i = index + 1; i < a.length; i++)
     
              temp[ i - 1] = a[i];
     
            a = temp;
     
        }

        // Made Into Instance Method
        
        public void print()
     
        {
     
           for(int i = 0 ; i < a.length; i++)
     
             System.out.println("a[" + i + "]: " + a[i]); 
     
        }

        // BubbleSort Method

        public void BubbleSort()
        {

            // I Do Not Know How To Do This

        }

    }