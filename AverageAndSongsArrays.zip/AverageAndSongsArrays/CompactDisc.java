// Jason Schwartz
// Lab Eight Part Two: Songs

import java.io.*;

/**
   This program creates a list of songs for a CD
   by reading from a file.
*/

public class CompactDisc
{
	
	public static void main(String[] args)throws IOException
	{
        // Opens/Reads The File "Classics.txt"

      FileReader file = new FileReader("Classics.txt");

      BufferedReader input = new BufferedReader(file);

      String title;

      String artist;

      String Song;

      // Task 3: This Declares An Int Array Of Song Objects Called "cd" With A Size Of 6

      Song [] cd = new Song [6];
      
      // This For Loop Continues Until The File Is Done

      for (int i = 0; i < cd.length; i++)

      {

          // Reads The Lines And Assigns Them To "title" and "artist"

          title = input.readLine();
          
          artist = input.readLine();

          // Task 3: This Fills The Array By Creating A New Song With The Title/Artist And Stores It In The Appropriate Position In The Array
          
          cd[i] = new Song(title, artist);

      }

      System.out.println("Contents of Classics:");

      // This For Loop Continues Until All The Contents Of The Array Are Printed

      for (int i = 0; i < cd.length; i++)
      {

          // Task 3: Print The Contents Of The Array To The Console

          System.out.println(cd[i].toString());
          
      }
      file.close();
   }
}