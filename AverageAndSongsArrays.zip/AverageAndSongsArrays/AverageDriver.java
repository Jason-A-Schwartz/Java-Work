// Jason Schwartz
// Lab Eight Average Driver

public class AverageDriver 

{
    public static void main(String [] args)
{
    Average avg = new Average();
    avg.calculateMean();
    avg.selectionSort();
    System.out.print(avg.toString());
}
}