// Jason Schwartz
// Lab Eight Averages

// Imports All The Utility Functions

import java.util.*;

public class Average

{
    // Needed To Use Keyboard Input 
    Scanner keyboard = new Scanner(System.in);
    
    // Declares The Array

    private int [] data = new int[5];

    //Decalres The Variable "mean"

    private double mean;
    
    // This Is The Average Constructor

    public Average()

    { 
        // For Loop To Prompt User For Score

        for(int x = 0; x < 5;)

        {
            // Prompt The User For A Score

            System.out.print("Enter Score: ");

            // Gets The Keyboard Input From User

            int userScore = keyboard.nextInt();

            // Stores The Score The User Input Into The Array

            data[x] = userScore;

            // Increases The Loop By One (This For Loop Now Only Takes In 5 Scores)

            x++;

        }
    }

    // This Is A Method For Calculating The Mean

    public void calculateMean()

    {

        // Initializes The Total Variable

        double total = 0;

        // This For Loop Assings The userScores To "Total"

        for(int x: data)

        {
            // Adds The Entered Score To The Total

            total += x;
        
        }

        // This Sets The Mean Equal To The Total Of The Entered Scores Divided By The Entered Scores "5")

        mean = (total / data.length);

    }

    // This Method Displays The User Scores And Calculated Mean

    public String toString()

    {
        // This Displays the Data
        String str = "Data: ";
        
        // This For Loop Stores The Data To Show

        for(int x: data)

        {

            str += x + " ";

        } 

        // This Stores The Mean into str And Displays It

        str += "\nMean: " + mean + "\n";

        System.out.print(" ");
        
        // This Returns str

        return str;

    }

    // This Method Makes The Data Be Shown In Descending Order

    public void selectionSort()

    {
        // Declares The Variables

        int startScan;
        int index;
        int maxIndex;
        int maxValue;

        // The For Loop Continues Untill All The Data Is Displayed
        for (startScan = 0; startScan < (data.length - 1); startScan++)

        {
            maxIndex = startScan;

            maxValue = data[startScan];

            // The For Loop Continues Untill All The Data Is Stored In Decending Order
            for (index = startScan + 1; index < data.length; index++)

            {
                // The If Statement Determines If The Value Is Greater Than The Other (For Descending Order)

                if (data[index] > maxValue)

                { 

                    maxValue = data[index];

                    maxIndex = index;

                }

            }

            data[maxIndex] = data[startScan];

            data[startScan] = maxValue;
        }
    }
}