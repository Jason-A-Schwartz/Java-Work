// Jason Schwartz
// Lab Seven TV model

public class Television
{

  private String manufacturer; // This Is The Manufacturer

  private int screensize; // This Is The Screensize

  boolean powerOn; // Turns Power On
  int channel; // Sets The Channel
  int volume; // Sets The Volume

  public Television(String brand, int size) // This Is The Constructor That pulls brand Variable And size Variable From TelivisionDemo
  {

    manufacturer = brand; // Sets manufacturer Equal To brand
    screensize = size; // Sets screensize Equal To size
    powerOn = false; // Sets powerOn Equal To False
    volume = 20; // Sets volume Equal To 20
    channel = 2; // Sets channel Equal To 2

  }
  
  /**
 * The getVolume Method Gets The Volume
 * @param volume volume Variable
 * @return Returns The Volume 
 */ 

  public int getVolume() // Method To Get Volume 
  {

    return volume; // Returns Volume

  }
  
  /**
 * The increaseVolume Method Increases The Volume By 1
 * @param volume volume Variable (+ 1)
 * @return Returns The Volume That Is Now Increased By 1
 */ 

  public void increaseVolume() // Method To Increase Volume
  {

    volume = (volume + 1); // Returns Increased Volume

  }
  
  /**
 * The decreaseVolume Method Decreases The Volume By 1
 * @param volume volume Variable (- 1)
 * @return Returns The Volume That Is Now Decrease By 1
 */ 

  public void decreaseVolume() // Method To Decrease Volume
  {

    volume = (volume - 1); // Returns Decreased Volume

  }
  
  /**
 * The getChanel Method Gets The Channel
 * @param channel channel Variable
 * @return Returns The Channel
 */ 

  public int getChannel() // Method To Get Channel
  {

    return channel; // Returns Channel
    
  }
  
  /**
 * The setChanel Method Sets The Channel
 * @param chooseChannel Sets The User Input (channel) Equal To chooseChannel Variable
 * @return Returns The Channel
 */ 

  public void setChannel(int chooseChannel) // Method To Get User Input For Channel
  {

    channel = chooseChannel; // Gets Users' Input For Channel

  }

   /**
 * The getManufacturer Method Sets Gets The Manufacturer
 * @param manufacturer manufacturer Variable
 * @return Returns The Manufacturer
 */ 

  public String getManufacturer() // Method To Get Manufacturer
  {

    return manufacturer; // Returns Manufacturer

  }

   /**
 * The getScreenSize Method Gets The Screen Size
 * @param screensize screensize Variable
 * @return Returns The Screen Size
 */ 

  public int getScreenSize() // Method To Get Screen Size
  {

    return screensize; // Returns Screen Size
    
  }

  /**
 * The Power Method Sets The Power On
 * @param powerOn powerOn Variable
 * @return Turns The Power On
 */ 

  public void power() // Method That Sets Power On
  {

    powerOn = !powerOn; // Turns Power On
    
  }
  }