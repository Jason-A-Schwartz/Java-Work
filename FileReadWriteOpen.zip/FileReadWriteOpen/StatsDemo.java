// Jason Schwartz
// Lab Five Files

// TASK #1 Add The File I/O Import Statement Here

import java.io.PrintWriter;
import java.io.FileReader;
import java.util.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileWriter;
import java.text.DecimalFormat;

/** This Class Reads Numbers From A File, Calculates The Mean And Standard Deviation, And Writes The Result To A File. */

public class StatsDemo
{
    // TASK #1 Add The Throws Clause
   public static void main(String[] args) throws IOException
   {
       double sum = 0;      // The Sum Of The Numbers
       int count = 0;       // The Number Of Numbers Added
       double mean = 0;     // The Average Of The Numbers
       double stdDev = 0;   // The Standard Deviation
       String filename;     // The Filename Input
       String line;         // To Hold A Line From The File
       double difference;   // The Value And Mean Difference
       
       // Create An Object Of Type Scanner And Decimal Format

       DecimalFormat threeD = new DecimalFormat("0.000");

       Scanner keyboard = new Scanner (System.in);

       // Describe The Program

       System.out.println("This program calculates " + "statistics on a file " + "containing a series of numbers");
       
       // Prompt The User And Read In The Filename
       
       System.out.print("Enter the file name:  ");
       filename = keyboard.nextLine();

       // TASK #2
       
       // Create a FileReader Object By Passing It The Filename
       
       FileReader File = new FileReader(filename);
       
       // Create A BufferedReader Object By Passing It The FileReader Object
       
       BufferedReader readFile = new BufferedReader(File);
       
       // Perform A Priming Read To Read The First Line Of The File
       
       line = readFile.readLine();
       
       // Loop For The Whole File Reading
       
       while(true)
       {
           line = readFile.readLine();

           if(line == null)
           break;

           else
            {
                // Convert The Line To A Double Value
                
                Double.parseDouble(line);
                
                // Add The Value To The Sum
                
                sum += Double.valueOf(line);
                
                // Increment The Counter
                
                count += 1; 
            }
        }
        
        // Close The Input File
        
        readFile.close();
        
        // Calculate And Store The Calculated Mean

        mean = (sum/count);
        
        // Reconnect The FileReader Object By Passing It The Filename Object
        
        FileReader File_read = new FileReader(filename);
        
        //Reconnect The BufferedReader Object By Passing It The FileReader Object
        
        BufferedReader read_File = new BufferedReader(File_read);
        
        // Reinitialize The Sum Of The Numbers
        
        sum = 0;
        
        // Reinitialize The Number Of Numbers Added

        count = 0;
        
        // Perform A Priming Read To Read The First Line Of The File
        
        line = read_File.readLine();
        
        // Loop Until You Are At The End Of The File
        
        while(true)
        {
            line = read_File.readLine();

            if(line == null)
            break;

            else
            {
                // Convert The Line Into A Double Value And Subtract The Mean
                
                difference = (Double.valueOf(line) - mean);
                
                // Add The Square Of The Difference To The Sum
                
                sum += Math.pow(difference, 2);
                
                // Increment The Counter
                
                count += 1;
            }
        }

        // Close The Input File

        read_File.close();
        
        // Calculate And Store The Calculated Standard Deviation

        stdDev = Math.sqrt(sum/count);

        // TASK 1:

        // Create A FileWriter Object Using "Results.txt"
        
        FileWriter write = new FileWriter("Results.txt");

        // Create A PrintWriter Object By Passing It The FileWriter Object

        PrintWriter output = new PrintWriter(write);

        // Print The Results To The Output File

        output.println("The Mean And Standard Deviation: ");
        output.println();
        output.println("Mean: " + threeD.format(mean));
        output.println();
        output.println("Standard Deviation: " + threeD.format(stdDev));

        // Close The Output File

        output.close();

        // Keyboard Close
        
        keyboard.close();
    }
}